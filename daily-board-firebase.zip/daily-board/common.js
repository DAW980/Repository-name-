/* Shared helpers for the TV screen (index.html) and the phone Admin page (admin.html). */
(function (w) {
  'use strict';
  var C = (w.Duty = {});

  C.PROJECT_ID = 'daily-2af13';
  C.DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  C.MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  C.PH = [['ref', 'Referrals + IPASS', 'External & Internal'], ['cr1', 'CR1', ''], ['cr2', 'CR2', ''], ['chamber', 'Chamber Room', '']];
  C.ROLES = ['Team leader', 'Assessment', 'Treatment', 'Operator', 'Attendant', 'Help'];

  C.$ = function (id) { return document.getElementById(id); };
  C.esc = function (s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  C.pad = function (n) { return (n < 10 ? '0' : '') + n; };

  // Oman is UTC+4 all year. The date and clock are computed by hand, so a wrong time zone on the TV does not matter.
  C.nowM = function () { return new Date(Date.now() + 4 * 3600000); };
  C.keyOf = function (d) { return d.getUTCFullYear() + '-' + C.pad(d.getUTCMonth() + 1) + '-' + C.pad(d.getUTCDate()); };
  C.todayKey = function () { return C.keyOf(C.nowM()); };
  C.parse = function (key) { var p = key.split('-'); return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])); };
  C.longDate = function (key) {
    var d = C.parse(key);
    return d.getUTCDate() + ' ' + C.MONTHS[d.getUTCMonth()] + ' ' + d.getUTCFullYear();
  };
  C.shortDay = function (key) {
    var d = C.parse(key);
    return C.DAYS[d.getUTCDay()].slice(0, 3) + ' ' + d.getUTCDate() + ' ' + C.MONTHS[d.getUTCMonth()].slice(0, 3);
  };

  C.query = function () {
    var o = {};
    (location.search || '').replace(/^\?/, '').split('&').forEach(function (kv) {
      if (!kv) return;
      var p = kv.split('=');
      try { o[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || ''); } catch (e) {}
    });
    return o;
  };

  // "Hassan Al Yusufi & Asma Al Harthi" counts as two people.
  C.countNames = function (roles) {
    var n = 0;
    C.ROLES.forEach(function (r) { if (roles && roles[r]) n += String(roles[r]).split(/\s*&\s*/).length; });
    return n;
  };

  // Add #dark to the address to get the dark version of the board.
  C.applyTheme = function () {
    var h = (location.hash || '').replace('#', '');
    if (h === 'dark') document.documentElement.setAttribute('data-board', 'dark');
    else document.documentElement.removeAttribute('data-board');
  };

  // On Firebase Hosting the project config is served at /__/firebase/init.json, so nothing needs pasting.
  // On any other host, paste the config into firebase-config.js.
  C.loadConfig = function (cb) {
    function fin(cfg) {
      cfg = cfg || {};
      if (!cfg.projectId) cfg.projectId = C.PROJECT_ID;
      cb(cfg);
    }
    if (w.FIREBASE_CONFIG && w.FIREBASE_CONFIG.projectId) { fin(w.FIREBASE_CONFIG); return; }
    try {
      var x = new XMLHttpRequest();
      x.open('GET', '/__/firebase/init.json', true);
      x.onreadystatechange = function () {
        if (x.readyState !== 4) return;
        var cfg = null;
        if (x.status === 200) { try { cfg = JSON.parse(x.responseText); } catch (e) {} }
        fin(cfg);
      };
      x.send();
    } catch (e) { fin(null); }
  };

  C.initFirebase = function (cb) {
    if (!w.firebase || !w.firebase.initializeApp) { cb(null, 'sdk'); return; }
    C.loadConfig(function (cfg) {
      try {
        if (!w.firebase.apps.length) w.firebase.initializeApp(cfg);
        var db = w.firebase.firestore();
        // Keeps the last data on screen when the internet drops.
        try { db.enablePersistence({ synchronizeTabs: true }).catch(function () {}); } catch (e) {}
        cb(db, null, cfg);
      } catch (e) { cb(null, 'init', e); }
    });
  };
})(window);
