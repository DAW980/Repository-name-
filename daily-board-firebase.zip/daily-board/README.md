# Daily Assignment Board (Firebase)

Project: `daily-2af13`
TV screen: https://daily-2af13.web.app/
Admin (phone): https://daily-2af13.web.app/admin

## One-time setup in the Firebase console (project daily-2af13)
1. Build > Firestore Database > Create database (production mode, nearest region).
2. Build > Authentication > Get started > Sign-in method > Email/Password > Enable.
3. Authentication > Users > Add user: your email and a strong password. This is the admin account.
   Optional: Authentication > Settings > User actions > turn off "Enable create (sign-up)".

## Deploy (Google Cloud Shell works from a phone browser: https://shell.cloud.google.com)
    unzip -o daily-board-firebase.zip && cd daily-board
    sed -i "s/REPLACE_WITH_ADMIN_EMAIL/your-email@example.com/" firestore.rules
    npx -y firebase-tools@13 login --no-localhost
    npx -y firebase-tools@13 deploy --project daily-2af13

## First use
Open /admin, sign in, press "Load starter data", then "Import to screen". The TV screen fills in at once.

## Every month
Send the new physicians and nurses tables to Claude. Claude returns two .json files. In /admin > Monthly rosters, pick each file and press "Import to screen".

## Files
index.html, board.js, board.css   TV screen (reads Firestore live)
admin.html, admin.js, admin.css   phone admin page
common.js, theme.css              shared code and colors
firebase-config.js                only needed if hosted outside Firebase Hosting
seed.json                         starter data, 25 Oct to 28 Nov 2026
firebase.json, .firebaserc        Hosting and Firestore setup for daily-2af13
firestore.rules                   anyone reads, only the admin email writes
