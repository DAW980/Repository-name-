/* Admin page for the phone. Signs in with the admin's email and password, then writes to Firestore.
   The security rules (firestore.rules) are what actually decide who may write; this page only offers the controls. */
(function () {
  'use strict';
  var D = window.Duty, $ = D.$, esc = D.esc;
  var db = null, auth = null, user = null;
  var dateKey = D.todayKey();
  var ro = null, ov = null, gotRo = false, gotOv = false, filled = false;
  var unsubs = [], staged = null;

  function msg(id, text, cls) { var el = $(id); el.textContent = text || ''; el.className = 'msg' + (cls ? ' ' + cls : ''); }
  function str(v) { return (typeof v === 'string' ? v : '').trim(); }

  function errText(e) {
    var c = e && e.code;
    if (c === 'permission-denied') return 'This account is not allowed to change the screen. Check the admin email in the Firestore rules.';
    if (c === 'unavailable') return 'No internet connection. Try again.';
    if (c === 'auth/wrong-password' || c === 'auth/invalid-credential' || c === 'auth/user-not-found' || c === 'auth/invalid-login-credentials') return 'Wrong email or password.';
    if (c === 'auth/invalid-email') return 'That email address is not valid.';
    if (c === 'auth/too-many-requests') return 'Too many attempts. Wait a few minutes and try again.';
    if (c === 'auth/network-request-failed') return 'No internet connection. Try again.';
    if (c === 'auth/operation-not-allowed') return 'Email and password sign-in is not turned on in the Firebase console.';
    if (c === 'auth/invalid-api-key' || c === 'auth/api-key-not-valid') return 'The Firebase config is missing. See firebase-config.js.';
    return 'Something went wrong. Try again.';
  }

  // ---- Day editor ----
  function slotRows() {
    var rows = [], ph = ro && ro.physicians, sf = ro && ro.staff;
    if (ph) D.PH.forEach(function (p) { rows.push(['ph:' + p[0], p[1], ph[p[0]]]); });
    if (sf && sf.roles) D.ROLES.forEach(function (r) { if (sf.roles[r]) rows.push(['st:' + r, r, sf.roles[r]]); });
    return rows;
  }
  function slotValues() {
    var v = {};
    Array.prototype.forEach.call(document.querySelectorAll('#slots [data-slot]'), function (i) {
      var x = i.value.trim(); if (x) v[i.getAttribute('data-slot')] = x;
    });
    return v;
  }
  function buildSlots(vals) {
    var rows = slotRows();
    $('slots').innerHTML = rows.length ? rows.map(function (r, i) {
      return '<div><label for="rp' + i + '">' + esc(r[1]) + ': <b>' + esc(r[2]) + '</b></label><input id="rp' + i + '" data-slot="' + esc(r[0]) + '" list="people" placeholder="Replace with" value="' + esc(vals[r[0]] || '') + '"></div>';
    }).join('') : '<p class="hint">No roster for this day yet. Import one below.</p>';
    var sf = ro && ro.staff;
    var auto = sf && sf.roles ? D.countNames(sf.roles) : 0;
    $('count-auto').textContent = auto ? '(automatic: ' + auto + ')' : '';
    $('oncall-base').textContent = sf && sf.onCall && sf.onCall.length ? '(roster: ' + sf.onCall.join(', ') + ')' : '';
  }
  function fillForm() {
    var o = ov || {};
    $('f-count').value = typeof o.count === 'number' ? o.count : '';
    $('f-note').value = o.note || '';
    $('f-oncall').value = (o.onCall || []).join(', ');
    buildSlots(o.replace || {});
  }

  function watchDay() {
    unsubs.forEach(function (u) { try { u(); } catch (e) {} });
    unsubs = []; ro = null; ov = null; gotRo = false; gotOv = false; filled = false;
    $('prev-link').href = '/?date=' + dateKey;
    msg('save-msg', '');
    function maybeFill() { if (!filled && gotRo && gotOv) { filled = true; fillForm(); } }
    unsubs.push(db.doc('roster/' + dateKey).onSnapshot(function (s) {
      ro = s.exists ? s.data() : null; gotRo = true;
      if (filled) buildSlots(slotValues()); else maybeFill();
    }, function () {}));
    unsubs.push(db.doc('overrides/' + dateKey).onSnapshot(function (s) {
      ov = s.exists ? s.data() : null; gotOv = true; maybeFill();
    }, function () {}));
  }

  function addPeople(list) {
    list = list.filter(Boolean);
    if (!list.length) return Promise.resolve();
    var fv = firebase.firestore.FieldValue;
    return db.doc('meta/people').set({ names: fv.arrayUnion.apply(fv, list) }, { merge: true });
  }

  function saveDay() {
    if (!db) return;
    var o = {}, c = $('f-count').value.trim();
    if (c !== '') o.count = Math.max(0, parseInt(c, 10) || 0);
    var note = $('f-note').value.trim(); if (note) o.note = note;
    var oc = $('f-oncall').value.split(',').map(function (x) { return x.trim(); }).filter(Boolean);
    if (oc.length) o.onCall = oc;
    var rep = slotValues(), names = oc.slice();
    Object.keys(rep).forEach(function (k) { names.push(rep[k]); });
    if (Object.keys(rep).length) o.replace = rep;

    var btn = $('save'); btn.disabled = true; msg('save-msg', 'Saving...');
    var p;
    if (!Object.keys(o).length) p = db.doc('overrides/' + dateKey).delete();
    else { o.updatedAt = firebase.firestore.FieldValue.serverTimestamp(); p = db.doc('overrides/' + dateKey).set(o); }
    p.then(function () { return addPeople(names); }).then(function () {
      msg('save-msg', 'Saved. The TV screen updates within a second.', 'ok');
    }).catch(function (e) { msg('save-msg', errText(e), 'bad'); }).then(function () { btn.disabled = false; });
  }

  function clearDay() {
    var btn = $('clear'); btn.disabled = true; msg('save-msg', 'Clearing...');
    db.doc('overrides/' + dateKey).delete().then(function () {
      $('f-count').value = ''; $('f-note').value = ''; $('f-oncall').value = ''; buildSlots({});
      msg('save-msg', 'Changes for this day were cleared.', 'ok');
    }).catch(function (e) { msg('save-msg', errText(e), 'bad'); }).then(function () { btn.disabled = false; });
  }

  // ---- Monthly import ----
  function normalize(obj) {
    var src = obj && obj.roster && typeof obj.roster === 'object' ? obj.roster : obj;
    var days = {}, nPh = 0, nSt = 0, names = {};
    function nm(x) { x = str(x); if (x) names[x] = 1; }
    Object.keys(src || {}).forEach(function (k) {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(k)) return;
      var v = src[k]; if (!v || typeof v !== 'object') return;
      var rec = {}, p = v.physicians, t = v.staff;
      if (p && typeof p === 'object') {
        var r = { ref: str(p.ref), cr1: str(p.cr1), cr2: str(p.cr2), chamber: str(p.chamber) };
        if (r.ref && r.cr1 && r.cr2 && r.chamber) { rec.physicians = r; nPh++; nm(r.ref); nm(r.cr1); nm(r.cr2); nm(r.chamber); }
      }
      if (t && typeof t === 'object') {
        var roles = {};
        D.ROLES.forEach(function (role) {
          var x = t.roles && t.roles[role];
          if (Array.isArray(x)) x = x.join(' & ');
          x = str(x);
          if (x) { roles[role] = x; x.split(/\s*&\s*/).forEach(nm); }
        });
        var oc = (Array.isArray(t.onCall) ? t.onCall : []).map(str).filter(Boolean);
        oc.forEach(nm);
        if (Object.keys(roles).length || oc.length) { rec.staff = { roles: roles, onCall: oc }; nSt++; }
      }
      if (rec.physicians || rec.staff) days[k] = rec;
    });
    (obj && Array.isArray(obj.people) ? obj.people : []).forEach(nm);
    return { days: days, nPh: nPh, nSt: nSt, people: Object.keys(names) };
  }

  function stage(obj) {
    var n = normalize(obj), keys = Object.keys(n.days).sort();
    $('imp-go').hidden = true; $('imp-prev').innerHTML = ''; staged = null;
    if (!keys.length) { msg('imp-msg', 'No days were found in that file.', 'bad'); return; }
    staged = n;
    var lines = keys.map(function (k) {
      var r = n.days[k], bits = [];
      if (r.physicians) bits.push('Physicians: ' + esc([r.physicians.ref, r.physicians.cr1, r.physicians.cr2, r.physicians.chamber].join(', ')));
      if (r.staff) bits.push('Nurses: ' + esc(D.ROLES.filter(function (x) { return r.staff.roles[x]; }).length) + ' roles, on call ' + esc(r.staff.onCall.join(', ') || 'none'));
      return '<div><b>' + esc(D.shortDay(k)) + '</b> ' + bits.join(' &middot; ') + '</div>';
    });
    $('imp-prev').innerHTML = '<p class="hint">' + keys.length + ' days found (' + n.nPh + ' physician days, ' + n.nSt + ' nurse days), from ' + esc(D.shortDay(keys[0])) + ' to ' + esc(D.shortDay(keys[keys.length - 1])) + '. Check the names, then import.</p><div class="prev">' + lines.join('') + '</div>';
    $('imp-go').hidden = false;
    msg('imp-msg', '');
  }

  function runImport() {
    if (!staged) return;
    var keys = Object.keys(staged.days), i = 0, go = $('imp-go');
    go.disabled = true; msg('imp-msg', 'Importing...');
    function next() {
      if (i >= keys.length) {
        return addPeople(staged.people).then(function () {
          msg('imp-msg', 'Imported ' + keys.length + ' days. The TV screen shows them now.', 'ok');
          $('imp-go').hidden = true; $('imp-prev').innerHTML = ''; staged = null;
          $('imp-file').value = '';
        });
      }
      var batch = db.batch(), n = 0;
      while (i < keys.length && n < 200) {
        var k = keys[i++], rec = staged.days[k], fields = Object.keys(rec), data = { date: k };
        fields.forEach(function (f) { data[f] = rec[f]; });
        fields.push('date');
        batch.set(db.doc('roster/' + k), data, { mergeFields: fields });
        n++;
      }
      return batch.commit().then(next);
    }
    next().catch(function (e) { msg('imp-msg', errText(e), 'bad'); }).then(function () { go.disabled = false; });
  }

  function readFile(f) {
    if (!f) return;
    msg('imp-msg', 'Reading the file...');
    var rd = new FileReader();
    rd.onload = function () {
      try { stage(JSON.parse(rd.result)); } catch (e) { msg('imp-msg', 'That file is not a valid roster file.', 'bad'); }
    };
    rd.onerror = function () { msg('imp-msg', 'Could not read the file.', 'bad'); };
    rd.readAsText(f);
  }

  function loadSeed() {
    msg('imp-msg', 'Loading starter data...');
    fetch('seed.json', { cache: 'no-store' }).then(function (r) { if (!r.ok) throw new Error('seed'); return r.json(); })
      .then(function (j) { stage(j); })
      .catch(function () { msg('imp-msg', 'Could not load the starter data.', 'bad'); });
  }

  // ---- Session ----
  function showSignedIn(u) {
    user = u;
    $('sec-signin').hidden = !!u;
    $('panel').hidden = !u;
    if (u) {
      $('who').innerHTML = 'Signed in as <b>' + esc(u.email || 'admin') + '</b>';
      db.doc('meta/people').onSnapshot(function (s) {
        var names = (s.exists && s.data().names) || [];
        $('people').innerHTML = names.slice().sort().map(function (n) { return '<option value="' + esc(n) + '">'; }).join('');
      }, function () {});
      $('f-date').value = dateKey;
      watchDay();
    } else {
      unsubs.forEach(function (x) { try { x(); } catch (e) {} });
      unsubs = [];
    }
  }

  function start() {
    D.initFirebase(function (d, why) {
      if (!d || !window.firebase.auth) { msg('boot', 'Could not start the data service. Check the internet connection and reload.', 'bad'); return; }
      db = d;
      try { auth = firebase.auth(); } catch (e) { msg('boot', errText(e), 'bad'); return; }
      $('boot').hidden = true;
      auth.onAuthStateChanged(function (u) { showSignedIn(u); if (!u) $('sec-signin').hidden = false; });
    });
  }

  $('signin').addEventListener('submit', function (ev) {
    ev.preventDefault();
    var b = $('si-btn'); b.disabled = true; msg('si-msg', 'Signing in...');
    auth.signInWithEmailAndPassword($('si-email').value.trim(), $('si-pass').value)
      .then(function () { msg('si-msg', ''); $('si-pass').value = ''; })
      .catch(function (e) { msg('si-msg', errText(e), 'bad'); })
      .then(function () { b.disabled = false; });
  });
  $('signout').addEventListener('click', function () { if (auth) auth.signOut(); });
  $('f-date').addEventListener('change', function () { var v = $('f-date').value; if (!v) return; dateKey = v; watchDay(); });
  $('save').addEventListener('click', saveDay);
  $('clear').addEventListener('click', clearDay);
  $('imp-file').addEventListener('change', function () { readFile($('imp-file').files && $('imp-file').files[0]); });
  $('seed').addEventListener('click', loadSeed);
  $('imp-go').addEventListener('click', runImport);
  D.applyTheme();
  start();
})();
