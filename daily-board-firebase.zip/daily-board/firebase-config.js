/* Leave this as null when the site is hosted on Firebase Hosting (the config is picked up automatically).
   Only if you host the page somewhere else (for example GitHub Pages), paste your web app config here:
   Firebase console > Project settings > Your apps > SDK setup and configuration > Config.

   window.FIREBASE_CONFIG = { apiKey: "...", authDomain: "daily-2af13.firebaseapp.com", projectId: "daily-2af13", appId: "..." };
*/
window.FIREBASE_CONFIG = null;
