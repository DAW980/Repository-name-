/* TV screen. Reads today's roster and today's manual changes live from Firestore:
     roster/{YYYY-MM-DD}     physicians + staff roles + on call, written by the monthly import
     overrides/{YYYY-MM-DD}  headcount, message, replacements, written from the Admin page
   Add ?date=YYYY-MM-DD to the address to preview another day. */
(function () {
  'use strict';
  var D = window.Duty, $ = D.$, esc = D.esc, pad = D.pad;
  var q = D.query();
  var fixed = /^\d{4}-\d{2}-\d{2}$/.test(q.date || '') ? q.date : null;
  var viewKey = fixed || D.todayKey();
  var db = null, unsubs = [], fatal = '';
  var st = fresh();

  function fresh() { return { ro: null, ov: null, gotRo: false, gotOv: false, cacheRo: true, cacheOv: true, err: false }; }

  function ini(n) { var s = String(n).replace(/^Dr\.?\s*/i, '').trim(); return s ? s.charAt(0).toUpperCase() : '?'; }
  function swap(ov, slot, base) {
    var r = ov.replace && ov.replace[slot];
    return r ? { n: r, r: true, b: base } : { n: base, r: false, b: base };
  }
  function repTag(x) { return x.r ? '<div class="rep">Replacement<span> for ' + esc(x.b) + '</span></div>' : ''; }
  function pills(arr) { return arr.map(function (n) { return '<span class="pill">' + esc(n) + '</span>'; }).join(''); }

  function render() {
    var key = viewKey, ov = st.ov || {};
    var ph = st.ro && st.ro.physicians, sf = st.ro && st.ro.staff;
    var d = D.parse(key), wd = d.getUTCDay(), weekend = (wd === 5 || wd === 6);

    var cnt = null;
    if (typeof ov.count === 'number') cnt = ov.count;
    else if (sf && sf.roles) { var n = D.countNames(sf.roles); if (n) cnt = n; }

    var h = '<header class="top"><div><div class="eyebrow">NHMC &middot; Daily Assignment</div><h1 class="day">' + D.DAYS[wd] + '</h1><div class="date">' + esc(D.longDate(key)) + (fixed ? '<span class="viewing">Preview</span>' : '') + '</div></div>';
    h += '<div class="side"><div class="clockbox"><div class="clock" id="clock"></div><div class="clock-l">Oman time</div></div><div class="count"><div class="num">' + (cnt === null ? '&mdash;' : esc(cnt)) + '</div><div class="lbl">Staff on duty</div></div></div></header>';
    if (ov.note) h += '<div class="note">' + esc(ov.note) + '</div>';

    var wait = fatal || (st.gotRo ? '' : 'Loading roster...');
    if (weekend) {
      h += '<section><div class="wk">Weekend</div><div class="empty">No physician roster on Fridays and Saturdays.</div></section>';
    } else {
      h += '<section><h2 class="sec">Physicians</h2>';
      if (ph) {
        h += '<div class="rooms">' + D.PH.map(function (p) {
          var x = swap(ov, 'ph:' + p[0], ph[p[0]]);
          return '<article class="room' + (p[0] === 'ref' ? ' room--lead' : '') + '"><div><div class="room-n">' + esc(p[1]) + '</div>' + (p[2] ? '<span class="room-s">' + esc(p[2]) + '</span>' : '') + '</div><div class="who"><span class="ring">' + esc(ini(x.n)) + '</span><span class="nm' + (x.n.length > 11 ? ' long' : '') + '">' + esc(x.n) + '</span></div>' + repTag(x) + '</article>';
        }).join('') + '</div>';
      } else {
        h += '<div class="empty">' + esc(wait || 'Physician roster not published for this date.') + '</div>';
      }
      h += '</section>';
      if (sf && sf.roles) {
        var cells = D.ROLES.filter(function (r) { return sf.roles[r]; }).map(function (r) {
          var x = swap(ov, 'st:' + r, sf.roles[r]);
          return '<div class="role"><div class="role-n">' + esc(r) + '</div><div class="role-w">' + esc(x.n) + '</div>' + repTag(x) + '</div>';
        });
        if (cells.length) h += '<section><h2 class="sec">Nursing Team</h2><div class="team">' + cells.join('') + '</div></section>';
      }
    }
    var oc = (ov.onCall && ov.onCall.length) ? ov.onCall : ((sf && sf.onCall) || []);
    if (oc.length) h += '<section class="oncall"><h2 class="sec">On call</h2>' + pills(oc) + '</section>';

    $('app').innerHTML = h;
    clock();
    live();
  }

  function clock() {
    var c = $('clock');
    if (!c) return;
    var n = D.nowM(), hh = n.getUTCHours();
    c.innerHTML = (hh % 12 || 12) + ':' + pad(n.getUTCMinutes()) + '<span class="s">:' + pad(n.getUTCSeconds()) + '</span><span class="ap">' + (hh >= 12 ? 'PM' : 'AM') + '</span>';
  }

  function live() {
    var el = $('live'), txt, cls = '';
    if (fatal) { txt = 'No connection'; cls = 'bad'; }
    else if (st.gotRo && st.gotOv && !st.cacheRo && !st.cacheOv) { txt = 'Live'; cls = 'ok'; }
    else if (st.err || navigator.onLine === false) { txt = st.gotRo ? 'Offline, showing last data' : 'Offline'; cls = 'bad'; }
    else { txt = 'Connecting'; }
    el.className = 'live ' + cls;
    el.lastChild.textContent = txt;
  }

  function subscribe() {
    unsubs.forEach(function (u) { try { u(); } catch (e) {} });
    unsubs = [];
    st = fresh();
    var opts = { includeMetadataChanges: true };
    function fail() { st.err = true; live(); }
    unsubs.push(db.doc('roster/' + viewKey).onSnapshot(opts, function (s) {
      st.ro = s.exists ? s.data() : null; st.gotRo = true; st.cacheRo = s.metadata.fromCache; st.err = false; render();
    }, fail));
    unsubs.push(db.doc('overrides/' + viewKey).onSnapshot(opts, function (s) {
      st.ov = s.exists ? s.data() : null; st.gotOv = true; st.cacheOv = s.metadata.fromCache; st.err = false; render();
    }, fail));
    render();
  }

  function tick() {
    clock();
    if (!fixed && db) {
      var t = D.todayKey();
      if (t !== viewKey) { viewKey = t; subscribe(); }
    }
    // One quiet reload at 03:00 Oman time keeps a screen that runs for weeks fresh.
    var n = D.nowM();
    if (n.getUTCHours() === 3 && n.getUTCMinutes() === 0 && n.getUTCSeconds() === 0 && navigator.onLine !== false) location.reload();
  }

  function wake() {
    try { if (navigator.wakeLock) navigator.wakeLock.request('screen').catch(function () {}); } catch (e) {}
  }

  D.applyTheme();
  window.addEventListener('hashchange', D.applyTheme);
  window.addEventListener('online', live);
  window.addEventListener('offline', live);
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') wake(); });
  wake();
  render();
  setInterval(tick, 1000);

  D.initFirebase(function (d, why) {
    if (!d) { fatal = why === 'sdk' ? 'Cannot reach the data service. Check the internet connection.' : 'Could not start the data service.'; render(); return; }
    db = d;
    subscribe();
  });
})();
